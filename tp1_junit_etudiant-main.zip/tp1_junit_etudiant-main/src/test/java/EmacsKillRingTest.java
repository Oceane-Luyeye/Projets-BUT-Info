import fr.einfolearning.tp2.metiers.EmacsKillRing;
import fr.einfolearning.tp2.metiers.exceptions.EmacsKillRingOverflowException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;


import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.lessThan;
public class EmacsKillRingTest {
    @Test
    public void testThrowException1() throws EmacsKillRingOverflowException {
        //Arrange
        EmacsKillRing emacsKillRing = new EmacsKillRing();

        //Act
        for(int i = 0; i< 19; i++) {
            emacsKillRing.add("Repetition" + (i+1));
            System.out.println(emacsKillRing.toString());
        }
        //Assert
        Assertions.assertDoesNotThrow(() -> emacsKillRing.add("20"));
        Assertions.assertThrows(EmacsKillRingOverflowException.class, () -> emacsKillRing.add("Repetition"));
    }

    @Test
    public void testEmptyEmacsKillRing() {
        //Arrange
        EmacsKillRing emacsKillRing = new EmacsKillRing();

        //Act
        //Assert
        //  Assertions.assertDoesNotThrow(() -> emacsKillRing.add("20"));
        Assertions.assertTrue(emacsKillRing.isEmpty());

    }

    @Test
    public void testToStringEmacsKillRing() throws EmacsKillRingOverflowException {
        //Arrange
        EmacsKillRing emacsKillRing = new EmacsKillRing();

        //Act

        emacsKillRing.add("One");
        emacsKillRing.add("Two");
        String excepted = emacsKillRing.toString();

        //Assert
        Assertions.assertEquals("[Two, One]",excepted);

    }

    @Test
    public void testCurrentEltEmacsKillRing() throws EmacsKillRingOverflowException {
        //Arrange
        EmacsKillRing emacsKillRing = new EmacsKillRing();

        //Act
        emacsKillRing.add("One");
        emacsKillRing.add("Two");

        String CE = emacsKillRing.currentElt();

        System.out.println(emacsKillRing);
        //Assert
        Assertions.assertEquals("Two", CE);

    }

    @Test
    public void testRotateEmacsKillRing() throws EmacsKillRingOverflowException {
        //Arrange
        EmacsKillRing emacsKillRing = new EmacsKillRing();

        //Act
        emacsKillRing.add("One");
        emacsKillRing.add("Two");
        emacsKillRing.add("Three");

        emacsKillRing.rotateFwd();

        String CE = emacsKillRing.currentElt();
        //Assert
       Assertions.assertEquals("Two", CE);

    }
}
