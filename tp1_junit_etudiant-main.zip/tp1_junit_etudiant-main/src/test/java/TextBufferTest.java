
import fr.einfolearning.tp2.metiers.TextBuffer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;


import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.lessThan;
public class TextBufferTest{
    @Test
    public void testToStringTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("Première Decouverte de Emacs par Occ Llmv !");
        String expectedS = "Première Decouverte de Emacs par Occ Llmv !";
        //Act

        String S = textBuffer.toString();

        //Assert
        assertThat(S, is(expectedS));
    }

    @Test
    public void testInsTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First Second");
        //Act

        textBuffer.ins("The",6 );

        String result1 = textBuffer.toString();
        String excepted = "First TheSecond";
        //Assert
        assertThat(result1, is(excepted));
    }

    @Test
    public void testInsInvalidPosTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First Second");
        //Act

        textBuffer.ins("The",50);

        String result1 = textBuffer.toString();
        String excepted = "First Second";
        //Assert
        assertThat(result1,is(result1));
    }


    @Test
    public void testMaxPTextBuffer(){
        //Arrange
        TextBuffer textBuffer = new TextBuffer("Première Decouverte de Emacs par Occ Llmv !");

        //Act
        int number = textBuffer.maxP();

        //Assert
       assertThat(number,is(43));
    }

    @Test
    public void testDelTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First");
        System.out.println(textBuffer.toString());
        //Act
        textBuffer.del(1,2);
        System.out.println(textBuffer.toString());
        String excepted = "Frst";
        //Assert
       assertThat(textBuffer.toString(),is(excepted));
    }

    @Test
    public void testDelLessFromTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First");
        System.out.println(textBuffer.toString());
        //Act
        textBuffer.del(-1,0);
        System.out.println(textBuffer.toString());
        String excepted = "First";
        //Assert
        assertThat(textBuffer.toString(),is(excepted));
    }
    @Test
    public void testDelLessToTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First");
        System.out.println(textBuffer.toString());
        //Act
        textBuffer.del(0,-1);
        System.out.println(textBuffer.toString());
        String excepted = "First";
        //Assert
        assertThat(textBuffer.toString(),is(excepted));
    }

    @Test
    public void testDelMaxToTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First");
        System.out.println(textBuffer.toString());
        //Act
        textBuffer.del(20,50);
        System.out.println(textBuffer.toString());
        String excepted = "First";
        //Assert
        assertThat(textBuffer.toString(),is(excepted));
    }

    @Test
    public void testSubStrTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First Second");
        //Act

        String result1 =  textBuffer.substr(0,5);

        String excepted = "First";
        //Assert
        assertThat(result1,is(excepted));
    }

    @Test
    public void testLessFromSubStrTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First Second");
        //Act

        String result1 =  textBuffer.substr(-5,0);

        String excepted = "";
        //Assert
        assertThat(result1,is(excepted));
    }

    @Test
    public void testMaxFromSubStrTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First Second");
        //Act

        String result1 =  textBuffer.substr(20,50);

        String excepted = "";
        //Assert
        assertThat(result1,is(excepted));
    }

   @Test
    public void testLessToSubStrTextBuffer(){
        //Arrange

        TextBuffer textBuffer = new TextBuffer("First Second");
        //Act

        String result1 =  textBuffer.substr(0,-5);

        String excepted = "";
        //Assert
        assertThat(result1,is(excepted));
    }
}
