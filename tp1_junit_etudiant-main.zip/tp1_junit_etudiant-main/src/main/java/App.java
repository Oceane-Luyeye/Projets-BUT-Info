//
// Utilisation nominale des classes td3.Buffer, Killring et td3.Editor
//
////////////////////////////////////////////////////////////////

import fr.einfolearning.tp2.metiers.EmacsKillRing;
import fr.einfolearning.tp2.metiers.TextBuffer;
import fr.einfolearning.tp2.metiers.TextEditor;
import fr.einfolearning.tp2.metiers.exceptions.EmacsKillRingOverflowException;

public class App {

    public static void main(String[] args) {
        // A completer


        /*Instanciation*/
        TextBuffer textBuffer = new TextBuffer("Première Decouverte de Emacs");

        EmacsKillRing emacsKillRing = new EmacsKillRing();

        TextEditor textEditor = new TextEditor("Deuxième Decouverte de Emacs");

        // Test class textBuffer

        try {
            System.out.println("Le textBuffer ressemble à ça : " + textBuffer.toString());
            System.out.println("Au début la taille du textBuffer est de : " + textBuffer.maxP());

            textBuffer.ins("L", 5);
            System.out.println("État du textbuffer après insersion d'un caractère: " + textBuffer.toString() + " Pour une longeur de : " + textBuffer.maxP());

            textBuffer.del(1, 10);
            System.out.println("État du textbuffer après suppression des caractères: " + textBuffer.toString() + " Pour une longeur de : " + textBuffer.maxP());

            textBuffer.substr(1, 5);
            System.out.println("État du textbuffer après copier-coller: " + textBuffer.substr(1, 5) + textBuffer.toString() + "Pour une longeur de " + textBuffer.maxP());

            //Test class textEditor

            System.out.println(" Au début la phrase ressemble à ça : " + textEditor.getBuffer());
            textEditor.setCursor(5);
            textEditor.setMark(3);
            //   textEditor.killRingBackup();
            System.out.println("Test de textEditor : " + textEditor.getBuffer());

            //  textEditor.killSection();
            System.out.println("Test de textEditor après : " + textEditor.getBuffer());


            //Test class Emacs

            System.out.println("Au début, lors de l'instanciation la chaine emacs est vide : " + emacsKillRing.toString());
            emacsKillRing.add("FirstElement");

            System.out.println("Puis, premier ajout d'une chaine de caractère " + emacsKillRing.toString());
            emacsKillRing.add("SecondElement");
            System.out.println("Puis, deuxième ajout d'une chaine de caractère " + emacsKillRing.toString());

            System.out.println("L'élément courant du tableau de caractère est:  " + emacsKillRing.currentElt());
            emacsKillRing.rotateFwd();

            System.out.println("L'élément courant est maintenant ci-dessous après le passage de la methode rotateFwd() ");
            System.out.println(emacsKillRing.currentElt());

        }catch (EmacsKillRingOverflowException e) {
            throw new RuntimeException(e);
        }
        }
}





